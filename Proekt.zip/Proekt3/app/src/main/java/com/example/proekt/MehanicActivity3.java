package com.example.proekt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MehanicActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mehanic3);
    }
}