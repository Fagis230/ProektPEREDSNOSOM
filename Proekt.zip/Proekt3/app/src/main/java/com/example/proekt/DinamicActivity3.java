package com.example.proekt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DinamicActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dinamic3);
    }
}