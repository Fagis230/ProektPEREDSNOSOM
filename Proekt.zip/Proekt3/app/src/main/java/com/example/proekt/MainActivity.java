package com.example.proekt;


import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;

public class MainActivity extends AppCompatActivity  {
    private static final String DATABASE_NAME = "ZAD1.db";
    private static final String TABLE_NAME = "questions1";
    private static final String COLUMN_TEM = "TEM";
    private static final String COLUMN_ID = "ID";
    private static final String COLUMN_TEXTZ = "TEXTZ";
    private static final String COLUMN_ANSWER = "ANSWER";
    private static final int NUM_COLUMN_TEM = 2;
    private static final int NUM_COLUMN_ANSWER = 5;
    private static final int NUM_COLUMN_TEXTZ = 5;
    private static final int DATABASE_VERSION  = 1;
    private Button button1;
    private Button button2;
    Button button_edit;
    EditText edit;
    EditText edit2;
    EditText edit3;
    SQLiteDatabase sqLiteDatabase;
    Button button_out;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        OpenHelper openHelper = new OpenHelper(MainActivity.this);
        sqLiteDatabase = openHelper.getWritableDatabase();
        button1 = (Button) findViewById(R.id.termo);
        button2 = (Button) findViewById(R.id.mehanic);
        button_out = (Button) findViewById(R.id.outbtn);
        button_edit = (Button) findViewById(R.id.editbtn);
        edit = (EditText) findViewById(R.id.edittext);
        edit2 = (EditText) findViewById(R.id.editanswer);
        edit3 = (EditText) findViewById(R.id.edittem);
        String zad = edit.getText().toString();
        String answer = edit2.getText().toString();
        String tem = edit3.getText().toString();
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Dinamic = new Intent(MainActivity.this,DinamicActivity.class);
                startActivity(Dinamic);

            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Mechanic = new Intent(MainActivity.this,MechanicActivity.class);
                startActivity(Mechanic);


            }
        });
        button_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContentValues contentValues = new ContentValues();
                switch (v.getId()){
                    case R.id.editbtn:
                        contentValues.put(COLUMN_TEXTZ,"rrrr");
                        contentValues.put(COLUMN_ANSWER,"sd");
                        contentValues.put( COLUMN_TEM,tem);
                        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
                        break;
                }
            }
        });
        button_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view1) {
                switch (view1.getId()){
                    case  R.id.outbtn:
                        Cursor cursor = sqLiteDatabase.query(TABLE_NAME, null, null, null, null, null, null);
                        if (cursor.moveToFirst()){
                            int idIndex  = cursor.getColumnIndex(COLUMN_ID);
                            int textIndex  = cursor.getColumnIndex(COLUMN_TEXTZ);
                            int answerIndex  = cursor.getColumnIndex(COLUMN_ANSWER);
                            int temIndex  = cursor.getColumnIndex(COLUMN_TEM);
                            do {
                                Log.d("mLog","id = " + cursor.getInt(idIndex)+
                                        ", text = " + cursor.getString(textIndex) + ",answer = "+
                                        cursor.getString(answerIndex)+",tem = "+ cursor.getString(temIndex));
                            } while (cursor.moveToNext());
                        }
                        else
                            Log.d("mLog","0 rows");
                        cursor.close();
                        break;
                }

            }
        });

    }
    private class OpenHelper extends SQLiteOpenHelper {

        OpenHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String query = "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID  + " integer primary key autoincrement, "
                    + COLUMN_TEXTZ +" TEXT, " + COLUMN_ANSWER + " VARCHAR(50), "+COLUMN_TEM + " VARCHAR(1) );";
            db.execSQL(query);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }

    }
}